<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Project;
use App\Models\User;
use App\Models\Board;
use App\Models\Card;
use App\Models\ProjectMember;
use Illuminate\Support\Str;

class ProjectController extends Controller
{
    public function tampilProject(Request $request)
    {
        $query = Project::with(['user', 'membersWithUsers', 'boards.cards']);

        // Search functionality
        if ($request->has('search') && $request->search != '') {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('project_name', 'like', '%' . $search . '%')
                  ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        $projects = $query->get();

        // Calculate progress for each project
        foreach ($projects as $project) {
            $totalCards = 0;
            $completedCards = 0;
            $inProgressCards = 0;

            foreach ($project->boards as $board) {
                foreach ($board->cards as $card) {
                    $totalCards++;
                    if ($card->status === 'done') {
                        $completedCards++;
                    }
                    if ($card->status === 'in_progress') {
                        $inProgressCards++;
                    }
                }
            }

            $progress = $totalCards > 0 ? round(($completedCards / $totalCards) * 100) : 0;

            $project->total_tasks = $totalCards;
            $project->completed_tasks = $completedCards;
            $project->in_progress_tasks = $inProgressCards;
            $project->progress_percentage = $progress;
            $project->tasks_count = $totalCards;
            $project->team_members_count = $project->membersWithUsers->count() + 1; // +1 for creator
        }

        return view('pages.admin.projects', compact('projects'));
    }

    public function tambahProject()
    {
        return view('pages.admin.create-project');
    }

    function storeProject(Request $request)
    {
        $request->validate([
            'project_name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
            'team_lead_id' => 'nullable|exists:users,id',
        ]);

        // Verify the selected user is actually a leader (if provided)
        if ($request->filled('team_lead_id')) {
            $teamLead = User::where('id', $request->team_lead_id)
                           ->where('role', 'leader')
                           ->first();

            if (!$teamLead) {
                return back()->withErrors(['team_lead_id' => 'Please select a valid team leader.'])
                            ->withInput();
            }

            // Check if leader already has a project
            $existingProject = Project::where('user_id', $request->team_lead_id)->first();
            if ($existingProject) {
                return back()->withErrors(['team_lead_id' => 'Leader sudah memiliki project: ' . $existingProject->project_name])
                            ->withInput();
            }
        }

        $project = Project::create([
            'project_name' => $request->project_name,
            'description' => $request->description,
            'deadline' => $request->due_date,
            'user_id' => $request->filled('team_lead_id') ? $request->team_lead_id : Auth::id(), // Use team leader ID or current admin ID
            'slug' => Str::slug($request->project_name, '-'),
        ]);

        // Project creator (admin/team leader) akan ditampilkan secara terpisah di UI
        // Jika tidak ada team leader yang dipilih, admin yang membuat project akan menjadi default

        return redirect()->route('admin.projects')->with('success', 'Project created successfully.');
    }

    public function edit($slug)
    {
        $project = Project::where('slug', $slug)->with('user')->firstOrFail();
        return view('pages.admin.update-project', compact('project'));
    }

    function updateProject(Request $request, $slug)
    {
        $request->validate([
            'project_name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
            'team_lead_id' => 'nullable|exists:users,id',
        ]);

        $project = Project::where('slug', $slug)->firstOrFail();

        // Update project data
        $updateData = [
            'project_name' => $request->project_name,
            'description' => $request->description,
            'deadline' => $request->due_date,
        ];

        // Only update user_id if team_lead_id is provided
        if ($request->filled('team_lead_id')) {
            // Verify the selected user is actually a leader
            $teamLead = User::where('id', $request->team_lead_id)
                           ->where('role', 'leader')
                           ->first();

            if ($teamLead) {
                // Check if leader already has another project (not this one)
                $existingProject = Project::where('user_id', $request->team_lead_id)
                                         ->where('id', '!=', $project->id)
                                         ->first();

                if ($existingProject) {
                    return back()->withErrors(['team_lead_id' => 'Leader sudah memiliki project: ' . $existingProject->project_name])
                                ->withInput();
                }

                $updateData['user_id'] = $request->team_lead_id;
            }
        }
        // If no team lead selected, we don't update user_id (keep existing value)

        $project->update($updateData);

        return redirect()->route('admin.projects')->with('success', 'Project updated successfully.');
    }

    /**
     * Search for team leaders by name
     */
    public function searchLeaders(Request $request)
    {
        $query = $request->get('q');
        $projectId = $request->get('project_id'); // For edit mode

        if (strlen($query) < 2) {
            return response()->json([]);
        }

        $leaders = User::where('role', 'leader')
                      ->where('name', 'LIKE', "%{$query}%")
                      ->with('createdProjects:id,project_name,user_id')
                      ->select('id', 'name', 'email')
                      ->limit(10)
                      ->get()
                      ->map(function($leader) use ($projectId) {
                          $hasProject = $leader->createdProjects->isNotEmpty();
                          $currentProject = $leader->createdProjects->first();

                          // Check if this is the current project being edited
                          $isCurrentProject = false;
                          if ($projectId && $currentProject) {
                              $isCurrentProject = $currentProject->id == $projectId;
                          }

                          return [
                              'id' => $leader->id,
                              'name' => $leader->name,
                              'email' => $leader->email,
                              'has_project' => $hasProject,
                              'project_name' => $hasProject ? $currentProject->project_name : null,
                              'is_current_project' => $isCurrentProject,
                          ];
                      });

        return response()->json($leaders);
    }

    /**
     * Show project details by slug
     */
    public function show($slug)
    {
        $project = Project::where('slug', $slug)
            ->with(['user', 'membersWithUsers', 'boards.cards.user'])
            ->firstOrFail();

        // Calculate progress data - FIXED: use 'done' not 'completed'
        $totalTasks = 0;
        $completedTasks = 0;
        $inProgressTasks = 0;
        $todoTasks = 0;

        foreach ($project->boards as $board) {
            foreach ($board->cards as $card) {
                $totalTasks++;
                if ($card->status === 'done') {
                    $completedTasks++;
                } elseif ($card->status === 'in_progress') {
                    $inProgressTasks++;
                } elseif ($card->status === 'todo') {
                    $todoTasks++;
                }
            }
        }

        $progressPercentage = $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100) : 0;

        // Get recent activities (recent card updates)
        $recentActivities = collect();
        foreach ($project->boards as $board) {
            $recentActivities = $recentActivities->merge($board->cards);
        }
        $recentActivities = $recentActivities->sortByDesc('updated_at')->take(5);

        return view('pages.admin.project-detail', compact(
            'project',
            'totalTasks',
            'completedTasks',
            'inProgressTasks',
            'todoTasks',
            'progressPercentage',
            'recentActivities'
        ));
    }

    /**
     * Show project board by slug
     */
    public function board($slug)
    {
        $project = Project::where('slug', $slug)->with('user')->firstOrFail();

        // Get or create board for this project
        $board = Board::firstOrCreate([
            'project_id' => $project->id
        ], [
            'board_name' => $project->project_name . ' Board',
            'description' => 'Kanban board for ' . $project->project_name,
            'position' => 1
        ]);

        // Get cards from database, grouped by status
        $cards = Card::where('board_id', $board->id)->with('user')->orderBy('position')->get();

        $boardData = [
            'todo' => $cards->where('status', 'todo')->values()->all(),
            'in_progress' => $cards->where('status', 'in_progress')->values()->all(),
            'review' => $cards->where('status', 'review')->values()->all(),
            'done' => $cards->where('status', 'done')->values()->all(),
        ];

        return view('pages.admin.board', compact('project', 'boardData'));
    }

    /**
     * Show create task form
     */
    public function createTask($slug)
    {
        $project = Project::where('slug', $slug)
            ->with(['user', 'projectMembers.user'])
            ->firstOrFail();

        // Get all project members with their work status
        $projectUsers = collect();

        // Add project members with status
        foreach ($project->projectMembers as $member) {
            if ($member->user) {
                $hasActiveTask = Card::where('user_id', $member->user_id)
                    ->where('status', '!=', 'done')
                    ->exists();

                $projectUsers->push([
                    'user' => $member->user,
                    'role' => $member->role,
                    'is_working' => $hasActiveTask
                ]);
            }
        }

        return view('pages.admin.add-task', compact('project', 'projectUsers'));
    }

    public function addMember(Request $request, $slug)
    {
        $project = Project::where('slug', $slug)->firstOrFail();

        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'role' => 'required|in:developer,designer'
        ]);

        // Check if user is already a member
        $existingMember = ProjectMember::where('project_id', $project->id)
            ->where('user_id', $validated['user_id'])
            ->exists();

        if ($existingMember) {
            return response()->json([
                'success' => false,
                'message' => 'User is already a member of this project'
            ], 400);
        }

        // Check if user is currently working on a task (status = working)
        $user = User::find($validated['user_id']);
        if ($user && $user->status === 'working') {
            return response()->json([
                'success' => false,
                'message' => "User {$user->name} is currently working on a task. Only users with 'free' status can be added to projects."
            ], 400);
        }

        ProjectMember::create([
            'project_id' => $project->id,
            'user_id' => $validated['user_id'],
            'role' => $validated['role'],
            'joined_at' => now()
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Member added successfully'
        ]);
    }

    /**
     * Remove member from project
     */
    public function removeMember($slug, $memberId)
    {
        $project = Project::where('slug', $slug)->firstOrFail();

        $member = ProjectMember::where('project_id', $project->id)
            ->where('id', $memberId)
            ->firstOrFail();

        $member->delete();

        return response()->json([
            'success' => true,
            'message' => 'Member removed successfully'
        ]);
    }

    /**
     * Search users for adding as members
     */
    public function searchUsers(Request $request)
    {
        $query = $request->get('q');
        $projectId = $request->get('project_id');

        if (strlen($query) < 2) {
            return response()->json([]);
        }

        // Get the project to exclude project manager from search
        $project = Project::find($projectId);

        // Get users that are not already members of this project
        $existingMemberIds = ProjectMember::where('project_id', $projectId)->pluck('user_id');

        // Also exclude the project manager from search results
        if ($project) {
            $existingMemberIds->push($project->user_id);
        }

        $users = User::whereNotIn('id', $existingMemberIds)
                    ->where(function($q) use ($query) {
                        $q->where('name', 'LIKE', "%{$query}%")
                          ->orWhere('email', 'LIKE', "%{$query}%");
                    })
                    ->where('role', '!=', 'admin') // Exclude admin users
                    ->select('id', 'name', 'email', 'role', 'status')
                    ->limit(10)
                    ->get();

        return response()->json($users);
    }

    /**
     * Store new task for a project
     */
    public function storeTask(Request $request, $slug)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:low,medium,high',
            'status' => 'required|in:todo,in_progress,review,done',
            'assignee' => 'nullable|exists:users,id',
            'due_date' => 'nullable|date|after_or_equal:today',
            'estimated_hours' => 'nullable|numeric|min:0|max:999.99',
        ]);

        // CHECK: User hanya bisa punya 1 task aktif (belum done)
        if ($request->assignee) {
            $hasActiveTask = Card::where('user_id', $request->assignee)
                ->where('status', '!=', 'done')
                ->exists();

            if ($hasActiveTask) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'User already has an active task. Please complete the current task first.');
            }
        }

        $project = Project::where('slug', $slug)->firstOrFail();

        // Get or create default board for this project
        $board = Board::firstOrCreate([
            'project_id' => $project->id
        ], [
            'board_name' => $project->project_name . ' Board',
            'description' => 'Kanban board for ' . $project->project_name,
            'position' => 1
        ]);

        // Create task card
        $card = Card::create([
            'board_id' => $board->id,
            'card_title' => $request->title,
            'description' => $request->description,
            'user_id' => $request->assignee,
            'due_date' => $request->due_date,
            'status' => $request->status,
            'priority' => $request->priority,
            'estimated_hours' => $request->estimated_hours
        ]);

        return redirect()->route('admin.projects.board', $project->slug)
                       ->with('success', 'Task "' . $request->title . '" created successfully!');
    }

    public function destroy($slug)
    {
        $project = Project::where('slug', $slug)->firstOrFail();

        // Hapus semua board dan card terkait (cascade delete)
        foreach ($project->boards as $board) {
            // Hapus semua card dalam board
            foreach ($board->cards as $card) {
                // Hapus subtask dan time logs
                $card->subtasks()->delete();
                $card->timeLogs()->delete();
                $card->delete();
            }
            $board->delete();
        }

        // Hapus project members
        $project->membersWithUsers()->delete();

        // Hapus project
        $projectName = $project->project_name;
        $project->delete();

        return redirect()->route('admin.projects')
                       ->with('success', "Project '{$projectName}' berhasil dihapus!");
    }

    /**
     * Approve submitted project
     */
    public function approveProject(Request $request, $slug)
    {
        $admin = Auth::user();

        $request->validate([
            'review_note' => 'nullable|string|max:1000',
        ]);

        $project = Project::where('slug', $slug)->with('user')->firstOrFail();

        // Check if project is submitted
        if ($project->status !== 'submitted') {
            return response()->json([
                'success' => false,
                'message' => 'Project hanya bisa di-approve jika statusnya submitted.'
            ], 400);
        }

        // Update project status to done
        $project->update([
            'status' => 'done',
            'review_note' => $request->review_note,
            'reviewed_at' => now(),
            'reviewed_by' => $admin->id,
        ]);

        // Update all users in this project to 'free' status
        // Get project leader
        $userIds = [];
        if ($project->user_id) {
            $userIds[] = $project->user_id;
        }

        // Get all project members
        $memberIds = \App\Models\ProjectMember::where('project_id', $project->id)
            ->pluck('user_id')
            ->toArray();

        $userIds = array_merge($userIds, $memberIds);
        $userIds = array_unique($userIds);

        // Update all users to free status
        if (!empty($userIds)) {
            User::whereIn('id', $userIds)->update(['status' => 'free']);
        }

        // Stop all active time logs for tasks in this project
        $boardIds = \App\Models\Board::where('project_id', $project->id)->pluck('id');
        $cardIds = \App\Models\Card::whereIn('board_id', $boardIds)->pluck('id');

        $activeLogs = \App\Models\Time_Log::whereIn('card_id', $cardIds)
            ->whereNull('end_time')
            ->get();

        foreach ($activeLogs as $log) {
            $log->stopWorkSession();
        }

        // Create notification for project leader
        \App\Models\Notification::create([
            'user_id' => $project->user_id,
            'type' => 'project_approved',
            'title' => 'Project Approved',
            'message' => "Project '{$project->project_name}' telah disetujui oleh admin {$admin->name}.",
            'data' => [
                'project_id' => $project->id,
                'project_name' => $project->project_name,
                'reviewed_by' => $admin->name,
                'review_note' => $request->review_note,
            ],
            'is_read' => false,
            'project_id' => $project->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Project berhasil di-approve!',
            'project' => [
                'id' => $project->id,
                'name' => $project->project_name,
                'status' => $project->status,
            ]
        ]);
    }

    /**
     * Reject submitted project
     */
    public function rejectProject(Request $request, $slug)
    {
        $admin = Auth::user();

        $request->validate([
            'review_note' => 'nullable|string|max:1000',
        ]);

        $project = Project::where('slug', $slug)->with('user')->firstOrFail();

        // Check if project is submitted
        if ($project->status !== 'submitted') {
            return response()->json([
                'success' => false,
                'message' => 'Project hanya bisa di-reject jika statusnya submitted.'
            ], 400);
        }

        // Update project status back to draft (rejected project automatically returns to draft)
        $project->update([
            'status' => 'draft',
            'review_note' => $request->review_note,
            'reviewed_at' => now(),
            'reviewed_by' => $admin->id,
            'submission_note' => null, // Clear submission note
            'submitted_at' => null, // Clear submitted timestamp
        ]);

        // Create notification for project leader
        \App\Models\Notification::create([
            'user_id' => $project->user_id,
            'type' => 'project_rejected',
            'title' => 'Project Rejected',
            'message' => "Project '{$project->project_name}' telah ditolak oleh admin {$admin->name}. Project dikembalikan ke status draft.",
            'data' => [
                'project_id' => $project->id,
                'project_name' => $project->project_name,
                'reviewed_by' => $admin->name,
                'review_note' => $request->review_note,
            ],
            'is_read' => false,
            'project_id' => $project->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Project telah di-reject dan dikembalikan ke status draft!',
            'project' => [
                'id' => $project->id,
                'name' => $project->project_name,
                'status' => $project->status,
            ]
        ]);
    }

    /**
     * Reset project status back to draft (after rejection)
     */
    public function resetProjectStatus(Request $request, $slug)
    {
        $project = Project::where('slug', $slug)->firstOrFail();

        // Can only reset rejected projects
        if ($project->status !== 'rejected') {
            return response()->json([
                'success' => false,
                'message' => 'Hanya project yang rejected yang bisa direset ke draft.'
            ], 400);
        }

        // Reset to draft status
        $project->update([
            'status' => 'draft',
            'submission_note' => null,
            'review_note' => null,
            'submitted_at' => null,
            'reviewed_at' => null,
            'reviewed_by' => null,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Status project berhasil direset ke draft!',
            'project' => [
                'id' => $project->id,
                'name' => $project->project_name,
                'status' => $project->status,
            ]
        ]);
    }
}
