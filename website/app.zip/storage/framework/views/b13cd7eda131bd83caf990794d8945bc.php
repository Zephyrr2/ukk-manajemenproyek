<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->user()->role === 'admin'): ?>
        <?php echo $__env->make('partials.sidebar-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif(auth()->user()->role === 'leader'): ?>
        <?php echo $__env->make('partials.sidebar-leader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('partials.sidebar-user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Notifications'); ?>
<?php $__env->startSection('page-title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <!-- Header Actions -->
    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900">All Notifications</h2>
            <div class="flex gap-2">
                <form action="<?php echo e(route('notifications.mark-all-read')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 text-sm text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition">
                        Mark all as read
                    </button>
                </form>
                <form action="<?php echo e(route('notifications.clear-read')); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete all read notifications?')">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 text-sm text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition">
                        Clear read
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Notifications List -->
    <div class="space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 <?php echo e($notification->is_read ? 'opacity-75' : ''); ?>">
                <div class="p-4">
                    <div class="flex items-start">
                        <!-- Icon -->
                        <div class="flex-shrink-0 mr-4">
                            <span class="text-3xl"><?php echo e($notification->icon); ?></span>
                        </div>

                        <!-- Content -->
                        <div class="flex-1 min-w-0">
                            <div class="flex items-start justify-between">
                                <div>
                                    <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                                        <?php echo e($notification->title); ?>

                                        <?php if(!$notification->is_read): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                                New
                                            </span>
                                        <?php endif; ?>
                                    </h3>
                                    <p class="text-gray-600 mt-1"><?php echo e($notification->message); ?></p>
                                    <p class="text-sm text-gray-400 mt-2"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                                </div>

                                <!-- Actions -->
                                <div class="flex items-center gap-2 ml-4">
                                    <?php if($notification->type === 'extension_request' && $notification->card && $notification->card->extension_status === 'pending'): ?>
                                        <form action="<?php echo e(route('leader.tasks.approve-extension', $notification->card_id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700">
                                                Approve
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('leader.tasks.reject-extension', $notification->card_id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                                                Reject
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('notifications.destroy', $notification->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-sm">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </div>

                            <!-- Task Details (if available) -->
                            <?php if($notification->data && isset($notification->data['task_title'])): ?>
                                <div class="mt-3 p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-700">
                                        <span class="font-medium">Task:</span> <?php echo e($notification->data['task_title']); ?>

                                    </p>
                                    <?php if(isset($notification->data['submitted_by'])): ?>
                                        <p class="text-sm text-gray-600 mt-1">
                                            <span class="font-medium">By:</span> <?php echo e($notification->data['submitted_by']); ?>

                                        </p>
                                    <?php endif; ?>
                                    <?php if(isset($notification->data['approved_by'])): ?>
                                        <p class="text-sm text-gray-600 mt-1">
                                            <span class="font-medium">Approved by:</span> <?php echo e($notification->data['approved_by']); ?>

                                        </p>
                                    <?php endif; ?>
                                    <?php if(isset($notification->data['rejected_by'])): ?>
                                        <p class="text-sm text-gray-600 mt-1">
                                            <span class="font-medium">Rejected by:</span> <?php echo e($notification->data['rejected_by']); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="bg-white rounded-lg shadow-sm p-8 text-center">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                </svg>
                <h3 class="mt-2 text-lg font-medium text-gray-900">No notifications</h3>
                <p class="mt-1 text-gray-500">You're all caught up!</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if($notifications->hasPages()): ?>
        <div class="mt-6">
            <?php echo e($notifications->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\ukk-manajemenproyek\website\resources\views/notifications/index.blade.php ENDPATH**/ ?>