<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('partials.sidebar-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('page-title', 'ADMIN DASHBOARD'); ?>
<?php $__env->startSection('page-subtitle', 'Welcome, Admin!'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Overview Section -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div class="flex items-center mb-4 sm:mb-6">
            <div class="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center mr-3 flex-shrink-0">
                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                </svg>
            </div>
            <h2 class="text-base sm:text-lg font-semibold text-gray-900">PROJECT OVERVIEW</h2>
        </div>

        <!-- Metrics Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-6 mb-8">
            <!-- Total Proyek -->
            <div class="bg-gray-50 rounded-lg p-3 sm:p-4 border">
                <div class="text-center">
                    <div class="text-xl sm:text-2xl font-bold text-gray-900"><?php echo e($totalProjects); ?></div>
                    <div class="text-xs sm:text-sm text-gray-600 mt-1">Total Projects</div>
                </div>
            </div>

            <!-- Tugas Selesai -->
            <div class="bg-gray-50 rounded-lg p-3 sm:p-4 border">
                <div class="text-center">
                    <div class="text-xl sm:text-2xl font-bold text-gray-900"><?php echo e($completedTasks); ?></div>
                    <div class="text-xs sm:text-sm text-gray-600 mt-1">Completed Tasks</div>
                </div>
            </div>

            <!-- Tugas Aktif -->
            <div class="bg-gray-50 rounded-lg p-3 sm:p-4 border">
                <div class="text-center">
                    <div class="text-xl sm:text-2xl font-bold text-gray-900"><?php echo e($activeTasks); ?></div>
                    <div class="text-xs sm:text-sm text-gray-600 mt-1">Active Tasks</div>
                </div>
            </div>

            <!-- Tugas Terlambat -->
            <div class="bg-gray-50 rounded-lg p-3 sm:p-4 border">
                <div class="text-center">
                    <div class="text-xl sm:text-2xl font-bold text-red-600"><?php echo e($overdueTasks); ?></div>
                    <div class="text-xs sm:text-sm text-gray-600 mt-1">Overdue Tasks</div>
                </div>
            </div>

            <!-- Anggota Aktif -->
            <div class="bg-gray-50 rounded-lg p-3 sm:p-4 border col-span-2 sm:col-span-1">
                <div class="text-center">
                    <div class="text-xl sm:text-2xl font-bold text-gray-900"><?php echo e($totalUsers); ?></div>
                    <div class="text-xs sm:text-sm text-gray-600 mt-1">Total Users</div>
                </div>
            </div>
        </div>
    </div>    <!-- Projects Section -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div class="flex items-center mb-4 sm:mb-6">
            <div class="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center mr-3 flex-shrink-0">
                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                </svg>
            </div>
            <h2 class="text-base sm:text-lg font-semibold text-gray-900">RECENT PROJECTS</h2>
        </div>

        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- Project Item -->
            <div class="border border-gray-200 rounded-lg p-3 sm:p-4">
                <div class="flex flex-col space-y-3">
                    <div class="flex items-start justify-between">
                        <div class="flex-1 min-w-0 mr-2">
                            <h3 class="font-medium text-sm sm:text-base text-gray-900 break-words">
                                <a href="<?php echo e(route('admin.projects.show', $project['slug'])); ?>" class="hover:text-green-600">
                                    <?php echo e($project['project_name']); ?>

                                </a>
                            </h3>
                            <p class="text-xs sm:text-sm text-gray-600 mt-1 break-words">By <?php echo e($project['creator']); ?></p>
                        </div>
                    </div>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0 text-xs sm:text-sm">
                        <div class="flex items-center">
                            <span class="text-gray-600">Progress: </span>
                            <span class="ml-1 font-medium <?php echo e($project['progress'] > 75 ? 'text-green-600' : ($project['progress'] > 40 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                <?php echo e($project['progress']); ?>%
                            </span>
                        </div>
                        <div class="flex items-center">
                            <span class="text-gray-600">Deadline: </span>
                            <span class="ml-1 font-medium text-gray-900 break-words">
                                <?php echo e($project['deadline'] ? \Carbon\Carbon::parse($project['deadline'])->format('d M Y') : 'Not set'); ?>

                            </span>
                        </div>
                    </div>
                </div>
                <!-- Progress Bar -->
                <div class="mt-3">
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="h-2 rounded-full <?php echo e($project['progress'] > 75 ? 'bg-green-500' : ($project['progress'] > 40 ? 'bg-yellow-500' : 'bg-red-500')); ?>"
                             style="width: <?php echo e($project['progress']); ?>%"></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-8">
                <div class="text-gray-500">No recent projects found</div>
                <a href="<?php echo e(route('admin.projects.create')); ?>" class="inline-block mt-2 text-green-600 hover:text-green-800">
                    Create your first project
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Team Members Section -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div class="flex items-center mb-4 sm:mb-6">
            <div class="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center mr-3 flex-shrink-0">
                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
                </svg>
            </div>
            <h2 class="text-base sm:text-lg font-semibold text-gray-900">TEAM MEMBERS</h2>
        </div>

        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- Team Member -->
            <div class="border border-gray-200 rounded-lg p-3 sm:p-4">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
                    <div class="flex items-center">
                        <div class="w-10 h-10 <?php echo e($member['role'] === 'Admin' ? 'bg-green-600' : ($member['role'] === 'Leader' ? 'bg-green-600' : 'bg-pink-600')); ?> rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <span class="text-white font-medium text-sm"><?php echo e($member['avatar']); ?></span>
                        </div>
                        <div class="min-w-0 flex-1">
                            <h3 class="font-medium text-sm sm:text-base text-gray-900 break-words"><?php echo e($member['name']); ?> <span class="text-gray-500">(<?php echo e($member['role']); ?>)</span></h3>
                        </div>
                    </div>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0 text-xs sm:text-sm pl-13 sm:pl-0">
                        <div class="text-gray-600"><?php echo e($member['completed_tasks']); ?> completed tasks</div>
                        <div class="font-medium <?php echo e($member['productivity'] > 80 ? 'text-green-600' : ($member['productivity'] > 60 ? 'text-yellow-600' : 'text-red-600')); ?>">
                            Productivity: <?php echo e($member['productivity']); ?>%
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-8">
                <div class="text-gray-500">No active team members found</div>
                <a href="<?php echo e(route('admin.users')); ?>" class="inline-block mt-2 text-green-600 hover:text-green-800">
                    Manage users
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\ukk-manajemenproyek\website\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>